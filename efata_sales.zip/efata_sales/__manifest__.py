# -*- coding: utf-8 -*-
{
    'name': "efata_sales",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','sale'],


    # always loaded 
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/sale_order_views.xml',
        # 'views/report_saleorder.xml',
        'views/report_price_quotation.xml',
        'views/report_saleorder.xml',
        'views/product_template_views.xml',
        'data/sequence.xml',
        'views/custom_bubble_layout.xml',
        'views/product_template_kanban_view.xml',
        'views/stock_report_list_view.xml',
        'views/product_product_inherit.xml',
        # 'security/groups.xml'
    ],
    'assets': {
            'web.assets_backend': [
                # 'efata_sales/static/src/js/colored_radio.js',
                # 'efata_sales/static/src/js/colored_circle.js',
            ],
    },
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

